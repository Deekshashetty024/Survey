document.getElementById("reg").addEventListener("click", makerequest);
document.getElementById("reg").addEventListener("click", validation);

var a = document.getElementById('firstname-err');
var b = document.getElementById('lastname-err');
var x = document.getElementById('email-err');
var y = document.getElementById('pass-err');
function validation() 
{

    var error1 = document.getElementById('email').value;
    var error2 = document.getElementById('password').value;
    var error3 = document.getElementById('firstname').value;
    var error4 = document.getElementById('lastname').value;


    if (error1.length == 0) {
        x.innerHTML = "Email is required";
    document.getElementById('email-err').style.color='red';
    return false;
    }
    if (error2.length == 0) 
    {
        y.innerHTML = "Password is required";
        document.getElementById('pass-err').style.color='red';
        return false;
    }
    if (error3.length == 0) {
        a.innerHTML = "firstname is required";
    document.getElementById('firstname-err').style.color='red';
    return false;
    }
    if (error4.length == 0) {
        b.innerHTML = "lastname is required";
    document.getElementById('lastname-err').style.color='red';
    return false;
    }
        // e.preventDefault()
 } 


        function makerequest(e) {
            e.preventDefault()
                // let firstname = document.getElementById("firstname").value
                // let lastname = document.getElementById("lastname").value
                // let email = document.getElementById("email").value
                // let password = document.getElementById("password").value

                const obj = {firstname: "John", lastname:"ree", email: "sujay@gmail.com",password: "324234"};

                   const myJSON = JSON.stringify(obj);

                console.log("Button Clicked")
                
                const myInit = {
                    method: 'POST',
                    headers: {
                    'Content-Type': 'application/json'
                    
                    },
                    body: myJSON
                    // body: JSON.stringify({ "firstname":"sujay", "lastname":"ree", "email": "sujay@gmail.com","password": "324234" })
                   }
                   console.log("Body:",myInit.body)
                     fetch("http://localhost:8084/api/signup", myInit)
               .then((res)=>{
                if(!res.ok){
                    throw Error(res.statusText)
                }
                return res.json()
               }).then((data)=>{
                console.log(data)
               }).catch((error)=>console.log(error))
        
        }
        